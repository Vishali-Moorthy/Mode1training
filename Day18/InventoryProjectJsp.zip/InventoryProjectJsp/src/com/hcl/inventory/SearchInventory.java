package com.hcl.inventory;

public class SearchInventory {
	private String stockid;

	public String getStockid() {
		return stockid;
	}

	public void setStockid(String stockid) {
		this.stockid = stockid;
	}
	
	public Inventory searchInventory() {
		return InventoryBAL.searchInventoryBal(stockid);
	}

}
